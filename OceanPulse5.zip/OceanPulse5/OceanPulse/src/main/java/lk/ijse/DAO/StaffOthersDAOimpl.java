package lk.ijse.DAO;

public class StaffOthersDAOimpl {
}
