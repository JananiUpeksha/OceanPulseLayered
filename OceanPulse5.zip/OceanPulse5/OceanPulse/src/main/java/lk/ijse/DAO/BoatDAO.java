package lk.ijse.DAO;

import lk.ijse.dto.BoatDto;
import lk.ijse.entity.Boat;

import java.sql.SQLException;
import java.util.List;

public interface BoatDAO extends CrudDAO<Boat> {
    /*@Override
    boolean save(BoatDto dto) throws SQLException, ClassNotFoundException;

    @Override
    boolean update(BoatDto dto) throws SQLException, ClassNotFoundException;

    @Override
    boolean delete(String id) throws SQLException, ClassNotFoundException;

    @Override
    BoatDto searchAll(String id) throws SQLException, ClassNotFoundException;

    @Override
    List<BoatDto> getAll() throws SQLException, ClassNotFoundException;*/

}
