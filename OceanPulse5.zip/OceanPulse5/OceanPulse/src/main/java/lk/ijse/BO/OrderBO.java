package lk.ijse.BO;

import java.sql.SQLException;
import java.time.LocalDate;

public interface OrderBO extends SuperBO{
    boolean saveOrder(String o_Id, LocalDate date, int qty, String c_id, String s_id) throws SQLException;
    public  String generateNextOrderId() throws SQLException;
    String getNextId(String currentId);
    boolean saveOrderDetails(String oId, String iId) throws SQLException;
}
