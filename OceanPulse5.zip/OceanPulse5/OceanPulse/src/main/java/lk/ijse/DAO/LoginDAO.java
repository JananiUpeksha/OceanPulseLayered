package lk.ijse.DAO;

public interface LoginDAO {
}
