package lk.ijse;

public class AppinitializerWrapper {
    public static void main(String[] args) {
        Appinitializer.main(args);
    }
}
