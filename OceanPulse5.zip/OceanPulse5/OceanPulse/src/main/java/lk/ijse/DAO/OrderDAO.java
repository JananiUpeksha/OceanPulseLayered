package lk.ijse.DAO;

import lk.ijse.db.Dbconnection;
import lk.ijse.dto.tm.AddTm;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;

public interface OrderDAO extends SuperDAO {
    public boolean saveOrder(String o_Id, LocalDate date, String c_id, String s_id) throws SQLException;
    public  String generateNextOrderId() throws SQLException;
    String getNextId(String currentId);
    boolean saveOrderDetails(List<AddTm> list, String oId) throws SQLException;
}
