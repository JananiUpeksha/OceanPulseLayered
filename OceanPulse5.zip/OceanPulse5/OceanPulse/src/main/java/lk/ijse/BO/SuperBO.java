package lk.ijse.BO;

public interface SuperBO {
}
