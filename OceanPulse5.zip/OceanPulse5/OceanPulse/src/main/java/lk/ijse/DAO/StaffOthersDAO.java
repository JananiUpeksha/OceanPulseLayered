package lk.ijse.DAO;

public interface StaffOthersDAO {
}
