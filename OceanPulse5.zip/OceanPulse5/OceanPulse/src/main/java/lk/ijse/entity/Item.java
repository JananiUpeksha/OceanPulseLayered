package lk.ijse.entity;

public class Item {
}
