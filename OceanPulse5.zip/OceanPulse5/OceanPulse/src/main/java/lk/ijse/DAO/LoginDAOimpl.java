package lk.ijse.DAO;

public class LoginDAOimpl {
}
